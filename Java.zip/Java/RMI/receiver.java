import java.io.*;  
import java.net.*;  
import java.util.*;
public class receiver {  
public static void main(String[] args) throws Exception{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter User Name:");
	String t=sc.nextLine();
	System.out.println("If Send the Put 1 and close the app put 2 other wise put anything to and receive the message-:");	
	int x=0;
while(x!=2){
	
	x=sc.nextInt();
	if(x==1){
		InputStreamReader r=new InputStreamReader(System.in);    
		BufferedReader br=new BufferedReader(r); 
		System.out.println("Enter Message-:");
		String s1=br.readLine();	
		try{      
			Socket s=new Socket("localhost",9999);  
			DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
			dout.writeUTF(s1);  
			dout.flush();  
			dout.close();  
			s.close();  
		}catch(Exception e){System.out.println(e);}  
	}
	else{
		try{  
		ServerSocket ss=new ServerSocket(9999);  
		Socket s=ss.accept(); 
		DataInputStream dis=new DataInputStream(s.getInputStream());  
		String  str=(String)dis.readUTF();  
		System.out.println(t+"-:"+str);  
		ss.close();  
		}catch(Exception e){System.out.println(e);}  
	}

}  
}  
}