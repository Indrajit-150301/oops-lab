
import java.rmi.*;
import java.rmi.registry.*;
public class SearchServer
{
	public static void main(String args[])
	{
		try
		{
			Search obj = new SearchQuery();

			LocateRegistry.createRegistry(9999);

			Naming.rebind("rmi://localhost:9999"+
						"/NileshMishra",obj);
		}
		catch(Exception ae)
		{
			System.out.println(ae);
		}
	}
}
