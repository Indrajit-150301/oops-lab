            FileWriter fileWriter = new FileWriter("myfile.txt");
            fileWriter.write("Person1: Hii there!! how are you \nPerson2: I am fine");
            fileWriter.close();

