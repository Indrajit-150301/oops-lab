public class B extends A{
    public void callB() {
        System.out.println("This is 'B' class");
    }
}
