package RMI;
public class ImplExample implements Hello {
    public void printMsg() {
        System.out.println("This is an example RMI program");
    }
}