public class A {
    public void callA() {
        System.out.println("This is 'A' class");


    }
}
