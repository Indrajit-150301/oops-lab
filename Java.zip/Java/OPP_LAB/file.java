import java.io.*;
import java.util.*;

class file
{
	public static void main(String []args) throws Exception
	{
		File newfile = new  File("abc3.txt");
		newfile.createNewFile();
		FileWriter filewrite= new FileWriter("abc3.txt");
		boolean t=true;
		
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(r);
		System.out.println("ENter the data");
		String s=br.readLine();
		filewrite.write(s);
		filewrite.close();
		
		
		System.out.println("\n\n\nDisplay\n");
		Scanner sc2= new Scanner(new FileInputStream("abc3.txt"));
		Scanner sc= new Scanner(newfile);
		while(sc.hasNextLine())
		{
			String ss=sc.nextLine();
			System.out.println(ss);
		}
		
		System.out.println("\n\n\nSearch\n");
		Scanner sc1 = new Scanner(System.in);
		
		String s1=sc1.nextLine();
		while(sc2.hasNextLine())
		{
			String sp=sc2.nextLine();
			if(sp.indexOf(s1)!=-1){
				t=true;
			}
		}
		
		if(t){
			System.out.println("Find");
		}else{
			System.out.println("NotFind");
		}
		
		sc.close();
	}
}