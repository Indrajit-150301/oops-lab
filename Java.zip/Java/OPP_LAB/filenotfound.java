import java.io.*;
import java.util.*;

class filenotfound
{
	public static void main(String []args)
	{
		try{
			File newfile = new File("abc.txt");
			FileInputStream fis= new FileInputStream(newfile);
			System.out.println("successfully..........");
		}catch(Exception e)
		{
			System.out.println(e);
		}
		finally{
			System.out.println("FInally");
		}
	}
}