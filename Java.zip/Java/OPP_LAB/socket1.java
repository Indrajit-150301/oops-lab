import java.util.*;
import java.io.*;
import java.net.*;
class socket1{
	public static void main(String[]args)throws Exception{
		Socket s=new Socket("localhost",9999);
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		InputStreamReader r=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(r);
		System.out.println("Enter Message-:");
		String sp=br.readLine();
		dos.writeUTF(sp);
		dos.flush();
		s.close();
	}
}