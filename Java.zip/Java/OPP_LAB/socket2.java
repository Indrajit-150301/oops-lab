import java.io.*;
import java.net.*;
import java.util.*;

class socket2{
	public static void main(String[]args)throws Exception{
	ServerSocket ss=new ServerSocket(9999);
	Socket s=ss.accept();
	DataInputStream ins=new DataInputStream(s.getInputStream());
	String str=(String)ins.readUTF();
	System.out.println(str);
	
	ss.close();
	
		
	}
}