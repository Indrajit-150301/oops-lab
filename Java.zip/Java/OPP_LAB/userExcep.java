import java.io.*;
import java.util.*;

class userExcep
{
/*	public int age(int x,int y) 
		{
			int z=x/y;
			System.out.println(z);
			return 0;
		}
	public static void main(String []args) throws Exception
	{
		userExcep ue = new userExcep();
		
		Scanner sc= new Scanner(System.in);
		int x,y;
		x=sc.nextInt();
		y=sc.nextInt();
		
		ue.age(x,y);
	}*/
	
	public int age(int x ){
		if(x > 18){
			throw new ArithmeticException("He is eligible for to vote in the Election");
		}
		else{
			System.out.println("Alge are right");
		}
		return 0;
	}
	public static void main(String []args) throws Exception{
		userExcep ue= new userExcep();
		int x ;
		Scanner sc= new Scanner(System.in);
		x=sc.nextInt();
		ue.age(x);
	}
}