import java.util.*;
import java .io.*;

class excep123 
{
	public static void main(String []args)
	{
		Scanner sc= new Scanner(System.in);
		int x,y,c ;
		System.out.println("Enter the value of x:");
		x=sc.nextInt();
		System.out.println("Enter the value of y:");
		y=sc.nextInt();
		
		try{
			c = x/y;
			System.out.println(c);
		}catch(Exception e ){
			System.out.println(e );
		}
	}
}