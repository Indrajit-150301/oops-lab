import java.io.*;
import java.util.*;
 class thread implements Runnable{
	 public void run(){
		 for(int i=0;i<10;i++)
			 System.out.println("Thread B-:"+i);
	 }
 }
 
 class First implements Runnable {
   
    public void run()
    {
       for(int i=0;i<10;i++){
	   System.out.println("Thread A-:"+i);}
    }
	
 
    public static void main(String []args)
    {
		thread t2=new thread();
        First g1 = new First();
        
        Thread t1 = new Thread(g1);
		Thread t3=new Thread(t2);
        t1.start();
		t3.start();
    }
}
