import java.util.Scanner;
class uncheckedException{
    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        
        int ch=0;

    do{
        System.out.println("Enter the exception you want to check");
        System.out.println("1.NullPointerException");
        System.out.println("2.ArithmaticException");
        System.out.println("3.ArrayIndexOutOfBoundException");
        System.out.println("4.NumberFormatException");
        System.out.println("5.ClasscastException");
        System.out.println("6.Exit");

        ch = s.nextInt();

        System.out.println("Output:::::::::::::::::::::");

        switch (ch) {
            case 1:
                try{
                        //NullPointerException
                        String str = "";
                        System.out.println(str.length());
                }catch(NullPointerException e){

                    System.out.println("NullPointerException is caught" + e.getMessage());

                }
            
                break;
            case 2:
                try {
                    //ArithmaticException
                    int a=10, b=0;
                    System.out.println(a/b);
                } 
                catch(ArithmeticException e) {
                   System.out.println("ArithmaticException is caught"+e.getMessage()); 
                }
                break;
            case 3:
                try {
                    //ArrayIndexOutOfBoundException
                    int[] arr={1,2,3};
                    System.out.println(arr[3]);
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("ArrayIndexOutOfBoundsException is caught"+e.getMessage());
                    
                }
                break;
            case 4:
                try {
                    //NumberFormatException
                    String str="abc";
                    int num = Integer.parseInt(str);
                    System.out.println(num);
                } catch (NumberFormatException e) {
                    System.out.println("NumberFormatException is caught"+e.getMessage());
                }
                break;
            case 5:
                try {
                    //ClasscastException
                    Object obj= new Object();
                    String st = (String)obj;
                } catch (ClassCastException e) {
                    System.out.println("ClassCastException is caught"+e.getMessage());
                    
                }
                break;
                 default:
                 System.out.println("Enter agian");
                break;
        }

        System.out.println("......................");
    }while(ch!=6);
    }
}