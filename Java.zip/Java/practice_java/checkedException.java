import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.SQLException;

public class checkedException {
    public static void main(String[] args) {
        // FileNotFoundException
        try{
            File file =new File("file.txt");
            FileReader filereader = new FileReader(file);
            
        }catch(FileNotFoundException e){
            System.out.println("FileNotFoundException: "+e.getMessage());
        }

        // SQL Exception

        try {
            throw new SQLException("SQL error");
            
        } catch(SQLException e) {
            System.out.println("SQLException is caught"+e.getMessage());
            
        }
        // ClassNotFoundException
        
    }
}
