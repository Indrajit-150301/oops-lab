import java.io.*;
import java.net.*;
import java.util.*;

public class Client
{
	@SuppressWarnings("resource")
	public static void main(String  []args) throws UnknownHostException, IOException
	{
	Socket sock = new Socket("localhost",4445);
	String filename = "abc.txt";
	File myfile = new File(filename);
	int FileSize = (int) myfile.length();
	OutputStream os = sock.getOutputStream();
	PrintWriter pr = new PrintWriter(sock.getOutputStream(),true);
	BufferedInputStream bis = new BufferedInputStream(new FileInputStream(myfile));
	Scanner in =new Scanner(sock.getInputStream());
	
	pr.println(filename);
	pr.println(FileSize);
	byte[ ] filebyte = new byte[FileSize];
	bis.read(filebyte,0,filebyte.length);
	os.write(filebyte,0,filebyte.length);
	System.out.println(in.nextLine());
	
	os.flush();
	sock.close();
	}
}