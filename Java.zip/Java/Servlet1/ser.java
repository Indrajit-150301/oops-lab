import javax.servlet.*;
import javax.servlet.http.*;


class RegisterServlet extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h2>Welcome to Register Servlet</h2>");
		String name =request.getParameter("user_name");
		String password =request.getParameter("user_password");
		String email =request.getParameter("user_email");
		String gender =request.getParameter("user_gender");
		String course =request.getParameter("user_course ");
		String cond =request.getParameter("user_condition");
		if(cond.equls("checked")){
			out.println("<h2>Name:"+name+"</h2>");
			out.println("<h2>password:"+password+"</h2>");
			out.println("<h2>email:"+email+"</h2>");
			out.println("<h2>gender:"+gender+"</h2>");
			out.println("<h2>course:"+course+"</h2>");
		}
		else{
			out.println("<h2>please accepted terms and condition</h2>");
		}
		
	}
}