import java.util.Scanner;
class A{
    Scanner sc = new Scanner(System.in);
    public String name;
    private int regno;
    protected String dept;
    public void getdata(){
        System.out.println("Enter your name:");
        name=sc.next();
        System.out.println("Enter your register number:");
        regno=sc.nextInt();
        System.out.println("Enter your department:");
        dept=sc.next();
    }
    protected void printdet(){
        System.out.println("Student Details");
        System.out.println("Name :"+name);
        System.out.println("Reg. No :"+regno);
        System.out.println("Department :"+dept);
    }
}
class B{
    Scanner sc = new Scanner(System.in);
    private int a,b;
    private String c= "OOPS Lab";
    protected void sum(){
        System.out.println("Enter two numbers :");
        a=sc.nextInt();
        b=sc.nextInt();
        System.out.println("The sum is "+(a+b));
    }
}
public class classesandobjectsworking {
    public static void main (String[] args){
        A obj1 = new A();
        obj1.getdata();
        obj1.printdet();
        B obj2 = new B();
        obj2.sum();
    }
}
