class Student {
	int id=101; // data member (also instance variable)
	String name="Rakesh"; // data member (also instance variable)

	public static void main(String args[])
	{
		Student s1 = new Student(); // creating an object of
			//s1.id="Rakesh";						// Student
		System.out.println(s1.id);
		System.out.println(s1.name);
	}
}
