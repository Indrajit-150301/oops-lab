public class Student {
    int id;
    String name;

    public static void main(String[] args) {
        Student s = new Student();
        Student s1 = new Student();

        s.id=102;
        s.name="Indrajit";
        s1.id=103;
        s1.name="Bharti";

        System.out.println(s.id+" "+ s.name);
        System.out.println(s1.id+" "+ s1.name);
    }
}


