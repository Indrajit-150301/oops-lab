// Generic Creating Single inheritance

class  A
{
    public void Display()
    {
        System.out.println("Create Display method");
    }
}

class Single_Generic extends A{
    public void print()
    {
        System.out.println("Create Print method");
    }

    public static void main(String []args)
    {
        Single_Generic object= new Single_Generic();
        object.Display();
        object.print();
    }
}